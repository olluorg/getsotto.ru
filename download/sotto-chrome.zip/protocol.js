// Чистые функции: из прочитанного на странице — сообщения в протоколе плагина IDEA
// (src/ide/server.rs, Incoming). Без chrome.*.

const LANGUAGES = {
  js: "javascript", ts: "typescript", py: "python", py3: "python", python3: "python", "c++": "cpp", cs: "csharp",
  kt: "kotlin", rb: "ruby", rs: "rust", go: "golang", "c++src": "cpp", csrc: "c", rustsrc: "rust", sh: "shell",
};

// CodeMirror 5 называет язык MIME-типом: text/x-java, text/x-c++src, text/typescript.
export function language(raw, name) {
  let l = (raw || "").toLowerCase().replace(/^(text|application)\/(x-)?/, "");
  if (!l && name && name.includes(".")) l = name.split(".").pop().toLowerCase();
  return LANGUAGES[l] || l;
}

// Номер строки → текст; полон, когда собраны 1…max без дыр.
export function accumulate(store, visible) {
  for (const [n, text] of visible) store.set(n, text);
  const max = Math.max(0, ...store.keys());
  const lines = [];
  let partial = false;
  for (let i = 1; i <= max; i++) {
    if (store.has(i)) lines.push(store.get(i));
    else {
      lines.push("");
      partial = true;
    }
  }
  return { text: lines.join("\n"), partial };
}

// Имя файла: из модели редактора, иначе из заголовка страницы.
export function fileName(editor, page, index) {
  const own = (editor.name || "").split("/").filter(Boolean).pop();
  if (own && own.includes(".")) return own;
  const base = (page.title || "solution").replace(/[\\/:*?"<>|]+/g, " ").trim().slice(0, 60) || "solution";
  const ext = { python: "py", javascript: "js", typescript: "ts", java: "java", cpp: "cpp", csharp: "cs", golang: "go", kotlin: "kt", rust: "rs", sql: "sql" }[language(editor.language, editor.name)] || "txt";
  return index ? `${base} ${index + 1}.${ext}` : `${base}.${ext}`;
}

export function project(page) {
  try {
    const u = new URL(page.url);
    return u.hostname + u.pathname.replace(/\/+$/, "");
  } catch (_) {
    return page.title || "browser";
  }
}

// В фокусе — тот, где курсор; иначе самый длинный.
export function main(editors) {
  return editors.find((e) => e.focused) || editors.slice().sort((a, b) => b.text.length - a.text.length)[0] || null;
}

export function messages(page, editors, now) {
  const names = editors.map((e, i) => fileName(e, page, i));
  const active = main(editors);
  const at = active ? editors.indexOf(active) : -1;
  const state = {
    type: "state",
    active: true,
    editor: active && {
      project: project(page),
      file: names[at],
      language: language(active.language, active.name),
      text: active.text,
      caret: { line: active.line || 1, column: active.column || 1 },
      stamp: now,
      partial: !!active.partial,
      selection: page.selection || null,
    },
  };
  const tree = editors.map((e, i) => ({ path: names[i], text: e.text, decls: [] }));
  // Условия на странице не нашлось — выделенный человеком текст и есть условие.
  const task = page.task || (page.selection && page.selection.length >= 60 ? page.selection : null);
  if (task) tree.unshift({ path: "task.md", text: task, decls: [] });
  const context = { type: "context", file: active ? names[at] : "", tabs: names, related: [], tree };
  return { state, context, output: page.output ? { type: "output", text: page.output } : null };
}

// Дёшево и без коллизий в пределах вкладки: длина и сумма кодов.
export function stamp(text) {
  let h = 0;
  for (let i = 0; i < text.length; i++) h = (h * 31 + text.charCodeAt(i)) | 0;
  return `${text.length}:${h}`;
}
