// Раз в секунду читает активную вкладку (reader.js) и передаёт изменившееся в соединение
// с sotto (offscreen.js — WebRTC живёт только в документе). Вход — через личный кабинет:
// токен расширения даёт только связь с sotto, не баланс. Только чтение.

import { read } from "./reader.js";
import { accumulate, messages, stamp } from "./protocol.js";

const SERVER = "https://api.getsotto.ru";
const PORT = 8788;
const PING_MS = 10_000;
const POLL_MS = 1_000;

let lastSent = {};
let focused = true;
let offscreenReady = false;
const scrolled = new Map(); // вкладка → номер строки → текст

function browserName() {
  const brands = (navigator.userAgentData && navigator.userAgentData.brands) || [];
  const named = brands.map((b) => b.brand).find((b) => !/Not.?A.?Brand|Chromium/i.test(b));
  return named || "Chromium";
}

async function settings() {
  const { token, server, port } = await chrome.storage.local.get(["token", "server", "port"]);
  return { token: token || "", server: server || SERVER, port: port || PORT, browser: browserName() };
}

function status(text) {
  chrome.storage.session.set({ status: text }).catch(() => {});
}

async function ensureOffscreen() {
  // Service worker проснулся, а документ жив: его «готово» прозвучало раньше.
  if (await chrome.offscreen.hasDocument()) {
    offscreenReady = true;
    return;
  }
  offscreenReady = false;
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["WEB_RTC"],
    justification: "Канал WebRTC с программой sotto: код со страницы собеседования.",
  });
}

async function pushConfig() {
  const config = await settings();
  if (!config.token) {
    status("войдите в аккаунт sotto");
    return;
  }
  await ensureOffscreen();
  if (offscreenReady) chrome.runtime.sendMessage({ target: "offscreen", type: "config", config }).catch(() => {});
}

function send(msg) {
  if (offscreenReady) chrome.runtime.sendMessage({ target: "offscreen", type: "send", msg }).catch(() => {});
}

function sendIfChanged(key, msg, sig) {
  if (lastSent[key] === sig) return;
  lastSent[key] = sig;
  send(msg);
}

// Вход как у программы (server/src/auth.rs): ссылка в кабинет, Яндекс ID или VK ID,
// подтверждение — и опрос, пока сервер не выдаст токен.
async function login() {
  const { server } = await settings();
  const start = await fetch(`${server}/auth/start`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ device: `${browserName()} · расширение sotto`, kind: "extension" }),
  }).then((r) => r.json());
  if (!start.sid || !start.link) throw new Error("сервер не начал вход");
  await chrome.tabs.create({ url: start.link });
  status("подтвердите подключение во вкладке личного кабинета");
  const deadline = Date.now() + (start.expires_in || 600) * 1000;
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, (start.interval || 3) * 1000));
    const reply = await fetch(`${server}/auth/poll`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ sid: start.sid }),
    })
      .then((r) => r.json())
      .catch(() => ({ status: "pending" }));
    if (reply.status === "ok") {
      await chrome.storage.local.set({ token: reply.token, login: reply.login || "" });
      status(`вход: ${reply.login || "выполнен"}`);
      return pushConfig();
    }
    if (reply.status !== "pending") break;
  }
  status("вход не завершён — попробуйте снова");
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab || !tab.url || !/^https?:/.test(tab.url)) return null;
  return tab;
}

async function poll() {
  if (!offscreenReady) return;
  const tab = await activeTab();
  if (!tab) return setActive(false);
  let frames;
  try {
    frames = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, world: "MAIN", func: read });
  } catch (_) {
    return setActive(false); // нет разрешения на сайт
  }
  const pages = frames.map((f) => f.result).filter(Boolean);
  const top = pages[0] || { url: tab.url, title: tab.title };
  const editors = pages.flatMap((p) => p.editors);
  const visible = pages.flatMap((p) => p.visible);
  if (!editors.length && visible.length) {
    const store = scrolled.get(tab.id) || new Map();
    scrolled.set(tab.id, store);
    const { text, partial } = accumulate(store, visible[0]);
    editors.push({ name: "", language: "", text, line: 1, column: 1, focused: true, partial });
  }
  const page = {
    url: top.url,
    title: top.title,
    task: pages.map((p) => p.task).find(Boolean),
    output: pages.map((p) => p.output).find(Boolean),
    selection: pages.map((p) => p.selection).find(Boolean),
  };
  if (!editors.length && !page.task) return blank();
  delete lastSent.blank;

  const now = Date.now();
  const { state, context, output } = messages(page, editors, now);
  const text = state.editor ? state.editor.text : "";
  const caret = state.editor ? `${state.editor.caret.line}:${state.editor.caret.column}` : "";
  // Отметка времени меняется только с текстом: по ней sotto видит правку.
  const textSig = stamp(text);
  if (textSig !== lastSent.text) {
    lastSent.text = textSig;
    lastSent.edited = now;
  }
  if (state.editor) state.editor.stamp = lastSent.edited;
  state.active = focused;
  sendIfChanged("state", state, `${tab.id}|${textSig}|${caret}|${focused}|${stamp(page.selection || "")}`);
  sendIfChanged("context", context, stamp(JSON.stringify(context.tree)) + context.file);
  // Пустую консоль не шлём — на многих площадках она просто свёрнута; но вывод прошлой
  // задачи при смене условия устарел, и sotto разбирал бы новую задачу по нему.
  const taskSig = stamp(page.task || "");
  if (output) {
    lastSent.outputTask = taskSig;
    sendIfChanged("output", output, stamp(output.text));
  } else if (lastSent.outputTask !== taskSig) {
    // И сразу после запуска: у sotto мог остаться вывод с прошлого раза.
    lastSent.outputTask = taskSig;
    sendIfChanged("output", { type: "output", text: "" }, stamp(""));
  }
}

// Вкладка без кода и условия: прежняя страница уже не на экране, sotto её забывает —
// иначе её условие оставалось задачей программы. Вернётесь — всё уйдёт заново.
function blank() {
  sendIfChanged("blank", { type: "blank" }, "1");
  for (const key of ["state", "context", "output", "outputTask", "focus"]) delete lastSent[key];
}

function setActive(active) {
  sendIfChanged("focus", { type: "focus", active: active && focused }, String(active && focused));
}

chrome.runtime.onMessage.addListener((m) => {
  if (m.target !== "background") return;
  if (m.type === "ready") {
    offscreenReady = true;
    lastSent = {};
    pushConfig();
  } else if (m.type === "status") status(m.text);
  else if (m.type === "login") login().catch((e) => status(`вход не удался: ${e.message}`));
  else if (m.type === "logout") {
    offscreenReady = false;
    chrome.storage.local.remove(["token", "login"]).then(() => chrome.offscreen.closeDocument().catch(() => {}));
    status("войдите в аккаунт sotto");
  }
});

chrome.windows.onFocusChanged.addListener((id) => {
  focused = id !== chrome.windows.WINDOW_ID_NONE;
  lastSent.state = null;
});
chrome.tabs.onRemoved.addListener((id) => scrolled.delete(id));
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.server || changes.port)) pushConfig();
});

// Будильник поднимает service worker после сна; соединение живёт в документе.
chrome.alarms.create("wake", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(() => pushConfig());
setInterval(() => send({ type: "ping" }), PING_MS);
setInterval(() => poll().catch(() => {}), POLL_MS);
pushConfig();
