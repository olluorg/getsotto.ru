// Выполняется в мире страницы (world: "MAIN") через chrome.scripting и сразу
// возвращает результат расширению: без глобальных имён, сообщений странице и правок DOM.
// Функция самодостаточна — chrome.scripting сериализует её текст.
export function read() {
  const editors = [];
  const seen = new Set();

  const push = (e) => {
    if (typeof e.text !== "string" || !e.text.trim() || seen.has(e.key)) return;
    seen.add(e.key);
    editors.push(e);
  };

  // Monaco: LeetCode, CoderPad, CodeSignal и многие другие.
  try {
    const m = window.monaco && window.monaco.editor;
    if (m) {
      const list = (m.getEditors && m.getEditors()) || [];
      for (const ed of list) {
        const model = ed.getModel && ed.getModel();
        if (!model) continue;
        const pos = ed.getPosition && ed.getPosition();
        push({
          key: "monaco:" + model.uri.toString(),
          name: model.uri.path || "",
          language: model.getLanguageId ? model.getLanguageId() : "",
          text: model.getValue(),
          line: pos ? pos.lineNumber : 1,
          column: pos ? pos.column : 1,
          focused: !!(ed.hasTextFocus && ed.hasTextFocus()),
        });
      }
      if (!list.length && m.getModels) {
        for (const model of m.getModels()) {
          push({ key: "monaco:" + model.uri.toString(), name: model.uri.path || "", language: model.getLanguageId ? model.getLanguageId() : "", text: model.getValue(), line: 1, column: 1, focused: false });
        }
      }
    }
  } catch (_) {}

  // CodeMirror 6: у .cm-content есть ссылка на EditorView — cmTile в новых версиях, cmView в старых.
  for (const el of document.querySelectorAll(".cm-content")) {
    try {
      const tile = el.cmTile || el.cmView;
      const view = tile && (tile.view || (tile.rootView && tile.rootView.view));
      if (!view) continue;
      const doc = view.state.doc;
      const head = view.state.selection.main.head;
      const line = doc.lineAt(head);
      push({ key: "cm6:" + editors.length, name: "", language: "", text: doc.toString(), line: line.number, column: head - line.from + 1, focused: !!view.hasFocus });
    } catch (_) {}
  }

  // CodeMirror 5.
  for (const el of document.querySelectorAll(".CodeMirror")) {
    try {
      const cm = el.CodeMirror;
      if (!cm) continue;
      const c = cm.getCursor();
      push({ key: "cm5:" + editors.length, name: "", language: String((cm.getOption("mode") || {}).name || cm.getOption("mode") || ""), text: cm.getValue(), line: c.line + 1, column: c.ch + 1, focused: cm.hasFocus() });
    } catch (_) {}
  }

  // Ace: HackerRank, Codility.
  for (const el of document.querySelectorAll(".ace_editor")) {
    try {
      const ed = (el.env && el.env.editor) || (window.ace && window.ace.edit(el));
      if (!ed) continue;
      const c = ed.getCursorPosition();
      const mode = (ed.session.$modeId || "").split("/").pop();
      push({ key: "ace:" + editors.length, name: "", language: mode, text: ed.getValue(), line: c.row + 1, column: c.column + 1, focused: ed.isFocused() });
    } catch (_) {}
  }

  // Модели не видно — видимые строки с номерами; расширение копит их по прокрутке.
  const visible = [];
  if (!editors.length) {
    const pair = (lines, numbers) => {
      const byTop = new Map();
      for (const n of numbers) {
        const v = parseInt(n.textContent, 10);
        if (v > 0) byTop.set(Math.round(n.getBoundingClientRect().top), v);
      }
      const out = [];
      for (const l of lines) {
        const v = byTop.get(Math.round(l.getBoundingClientRect().top));
        if (v) out.push([v, l.textContent.replace(/\u00a0/g, " ")]);
      }
      return out;
    };
    for (const root of document.querySelectorAll(".monaco-editor")) {
      const got = pair(root.querySelectorAll(".view-line"), root.querySelectorAll(".line-numbers"));
      if (got.length) visible.push(got);
    }
    for (const root of document.querySelectorAll(".cm-editor")) {
      const got = pair(root.querySelectorAll(".cm-line"), root.querySelectorAll(".cm-lineNumbers .cm-gutterElement"));
      if (got.length) visible.push(got);
    }
  }

  // Простое поле ввода — последний вариант.
  if (!editors.length && !visible.length) {
    let best = null;
    for (const t of document.querySelectorAll("textarea")) {
      if (t.offsetParent && t.value.split("\n").length >= 3 && (!best || t.value.length > best.value.length)) best = t;
    }
    if (best) {
      const before = best.value.slice(0, best.selectionStart).split("\n");
      push({ key: "textarea", name: "", language: "", text: best.value, line: before.length, column: before[before.length - 1].length + 1, focused: document.activeElement === best });
    }
  }

  const text = (sel) => {
    for (const s of sel) {
      const el = document.querySelector(s);
      const t = el && el.innerText && el.innerText.trim();
      if (t) return t;
    }
    return null;
  };

  const task = text([
    '[data-track-load="description_content"]',
    '[data-cy="question-title"] ~ div',
    ".challenge-body-html",
    ".problem-statement",
    ".challenge-text",
    '[data-testid="instructions"]',
    '[class*="instructions" i]',
    '[class*="problem-description" i]',
    '[class*="task-description" i]',
    '[class*="statement" i]',
  ]);

  const output = text([
    '[data-e2e-locator="console-result"]',
    '[data-layout-path*="testcase"] [class*="result" i]',
    ".compile-message",
    ".test-case-result",
    '[class*="console-output" i]',
    '[class*="test-results" i]',
    '[class*="output-panel" i]',
  ]);

  // Разметки площадки не знаем — условие по смыслу: самый узкий блок без редактора, где есть
  // хотя бы две разные метки — «Формат ввода» и «Пример» и т. п. (CodeRun, Контест, Codeforces).
  const statement = () => {
    const marks = /(Формат ввода|Формат вывода|Входные данные|Выходные данные|Ограничения|Пример|Input format|Output format|Constraints|Example)/gi;
    const editor = ".monaco-editor, .cm-editor, .CodeMirror, .ace_editor";
    let best = null;
    for (const el of document.querySelectorAll("article, section, main, div")) {
      const t = el.innerText || "";
      if (t.length < 200 || t.length > 20000 || el.closest(editor) || el.querySelector(editor)) continue;
      const kinds = new Set((t.match(marks) || []).map((m) => m.toLowerCase()));
      if (kinds.size >= 2 && (!best || t.length < best.length)) best = t;
    }
    return best && best.trim();
  };

  const selection = (() => {
    const s = window.getSelection && window.getSelection();
    const t = s ? s.toString().trim() : "";
    return t ? t.slice(0, 8000) : null;
  })();

  const found = task || statement();
  return { url: location.href, title: document.title, editors, visible, task: found && found.slice(0, 8000), output: output && output.slice(-4000), selection };
}
