// Соединение с sotto: WebRTC есть только в документе, не в service worker — поэтому здесь.
// Сигнализация — сервер sotto (/v1/link); его нет — sotto на этой машине (/ide/link), и
// время от времени снова сервер. Данные идут каналом WebRTC напрямую или через TURN
// сервера, зашифрованными. Сообщения те же, что у плагина IDEA (src/ide/server.rs).

const RETRY_SERVER_MS = 60_000;
const GATHER_MS = 4_000;

let config = null; // { server, token, port, browser }
let signal = null; // { ws, local }
let ice = [];
let pc = null;
let dc = null;
let program = null;
const latest = {}; // последнее состояние каждого вида — при новом канале шлётся заново
let retryServer = null;

function status(text) {
  chrome.runtime.sendMessage({ target: "background", type: "status", text }).catch(() => {});
}

function wsUrl(base, path) {
  return base.replace(/^https:/, "wss:").replace(/^http:/, "ws:").replace(/\/+$/, "") + path;
}

function openSignal(url, local) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(url);
    const timer = setTimeout(() => {
      ws.close();
      reject(new Error("нет ответа"));
    }, 8_000);
    ws.onopen = () => {
      clearTimeout(timer);
      resolve(ws);
    };
    ws.onerror = () => {
      clearTimeout(timer);
      reject(new Error("не подключиться"));
    };
    ws.onmessage = (e) => onSignal(JSON.parse(e.data));
    ws.onclose = () => {
      if (signal && signal.ws === ws) {
        signal = null;
        setTimeout(connect, 2_000);
      }
    };
    ws.local = local;
  });
}

async function connect() {
  if (!config || !config.token || signal) return;
  const token = encodeURIComponent(config.token);
  try {
    const ws = await openSignal(wsUrl(config.server, `/v1/link?t=${token}`), false);
    signal = { ws, local: false };
    status("связь через сервер sotto");
    clearInterval(retryServer);
    retryServer = null;
    return;
  } catch (_) {}
  try {
    const ws = await openSignal(`ws://127.0.0.1:${config.port}/ide/link?t=${token}`, true);
    signal = { ws, local: true };
    status("сервер sotto недоступен — связь с sotto на этом компьютере");
    // Канал данных от сигнализации не зависит: сервер нужен для следующего соединения.
    if (!retryServer) retryServer = setInterval(tryServer, RETRY_SERVER_MS);
  } catch (_) {
    status("sotto не найден: запущен ли он и выполнен ли вход?");
    setTimeout(connect, 10_000);
  }
}

async function tryServer() {
  if (!signal || !signal.local) return;
  try {
    const ws = await openSignal(wsUrl(config.server, `/v1/link?t=${encodeURIComponent(config.token)}`), false);
    const old = signal.ws;
    signal = { ws, local: false };
    old.close();
    clearInterval(retryServer);
    retryServer = null;
    status("связь через сервер sotto");
  } catch (_) {}
}

function sendSignal(msg) {
  if (signal && signal.ws.readyState === WebSocket.OPEN) signal.ws.send(JSON.stringify(msg));
}

function onSignal(msg) {
  if (msg.type === "ice") ice = msg.servers || [];
  else if (msg.type === "program") {
    if (msg.conn === program && pc) return;
    program = msg.conn;
    closePeer();
    if (program !== null && program !== undefined) startPeer(msg.device);
    else status("sotto не запущен на этом аккаунте");
  } else if (msg.type === "signal" && msg.data && msg.data.answer && pc) {
    pc.setRemoteDescription({ type: "answer", sdp: msg.data.answer }).catch((e) => status(`ответ sotto не принят: ${e.message}`));
  }
}

function closePeer() {
  if (dc) dc.onclose = null;
  if (pc) pc.close();
  pc = null;
  dc = null;
}

// Без «trickle»: кандидаты — в самом предложении, сигнализации одно сообщение.
async function startPeer(device) {
  pc = new RTCPeerConnection({ iceServers: ice });
  const mine = pc;
  dc = pc.createDataChannel("sotto");
  dc.onopen = () => {
    status(device ? `подключено к sotto на «${device}»` : "подключено к sotto");
    dc.send(JSON.stringify({ type: "hello", ide: config.browser, kind: "browser", pid: 0, host: "" }));
    for (const msg of Object.values(latest)) dc.send(JSON.stringify(msg));
  };
  dc.onclose = () => {
    if (pc !== mine) return;
    status("канал с sotto закрыт — соединяюсь заново");
    closePeer();
    setTimeout(() => program !== null && !pc && startPeer(device), 2_000);
  };
  pc.onconnectionstatechange = () => {
    if (pc === mine && pc.connectionState === "failed") dc.onclose && dc.onclose();
  };
  await pc.setLocalDescription(await pc.createOffer());
  await new Promise((resolve) => {
    if (pc.iceGatheringState === "complete") return resolve();
    const timer = setTimeout(resolve, GATHER_MS);
    pc.onicegatheringstatechange = () => {
      if (pc.iceGatheringState === "complete") {
        clearTimeout(timer);
        resolve();
      }
    };
  });
  if (pc !== mine) return;
  sendSignal({ type: "signal", data: { offer: pc.localDescription.sdp } });
  status("соединяюсь с sotto…");
}

function deliver(msg) {
  if (msg.type !== "ping" && msg.type !== "hello") latest[msg.type] = msg;
  if (dc && dc.readyState === "open") dc.send(JSON.stringify(msg));
}

chrome.runtime.onMessage.addListener((m) => {
  if (m.target !== "offscreen") return;
  if (m.type === "config") {
    const changed = !config || config.token !== m.config.token || config.server !== m.config.server || config.port !== m.config.port;
    config = m.config;
    if (changed) {
      if (signal) {
        const old = signal.ws;
        signal = null;
        old.close();
      }
      closePeer();
      program = null;
      connect();
    }
  } else if (m.type === "send") deliver(m.msg);
});

chrome.runtime.sendMessage({ target: "background", type: "ready" }).catch(() => {});
