const $ = (id) => document.getElementById(id);

async function refresh() {
  const { status } = await chrome.storage.session.get("status");
  const { token, login } = await chrome.storage.local.get(["token", "login"]);
  $("status").textContent = status || "…";
  $("account").textContent = token ? `аккаунт: ${login || "вход выполнен"}` : "";
  $("login").hidden = !!token;
  $("logout").hidden = !token;
}

async function init() {
  const { server, port } = await chrome.storage.local.get(["server", "port"]);
  $("server").value = server || "";
  $("port").value = port || "";
  refresh();
  setInterval(refresh, 1000);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let origin = null;
  try {
    origin = new URL(tab.url).origin + "/*";
  } catch (_) {}
  if (!origin || !/^https?:/.test(origin)) {
    $("site").disabled = true;
    return;
  }
  const granted = await chrome.permissions.contains({ origins: [origin] });
  $("site").disabled = granted;
  $("site-hint").textContent = granted ? "Этот сайт читается." : "Сайта нет в списке площадок — разрешите явно.";
  $("site").onclick = async () => {
    const ok = await chrome.permissions.request({ origins: [origin] });
    $("site").disabled = ok;
    $("site-hint").textContent = ok ? "Этот сайт читается." : "Разрешение не дано.";
  };
}

$("login").onclick = () => chrome.runtime.sendMessage({ target: "background", type: "login" });
$("logout").onclick = () => chrome.runtime.sendMessage({ target: "background", type: "logout" });
$("save").onclick = async () => {
  const server = $("server").value.trim().replace(/\/+$/, "");
  const port = parseInt($("port").value, 10) || null;
  await chrome.storage.local.set({ server, port });
};

init();
